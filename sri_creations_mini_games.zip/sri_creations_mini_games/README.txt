SRI CREATIONS | SRI MINI GAMES

RUN ON YOUR LAPTOP
1. Download and extract sri_creations_mini_games.zip.
2. Open the folder.
3. Double-click index.html. It opens in Chrome, Edge, Firefox, or another modern browser.
4. No install, account, server, or paid tool is required.

PUBLISH ONLINE FOR FREE
You can publish this static website using GitHub Pages or Netlify. Create an account with the hosting provider, upload index.html (or the extracted project folder), and follow its publish instructions. Your exact public URL will be provided by the hosting service.

NOTES
- The website opens with the SRI CREATIONS welcome screen.
- It includes 10 playable mini games and a session score counter.
- Scores are kept only while the page remains open; they are not saved to a server.
- Snake uses keyboard arrows and on-screen direction buttons. Catch the Star uses on-screen controls and keyboard arrows.
